from django.apps import AppConfig


class ProfileOfUserConfig(AppConfig):
    name = 'profile_of_user'
