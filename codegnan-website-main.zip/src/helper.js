function show_text(){
    console.log("hello");
}