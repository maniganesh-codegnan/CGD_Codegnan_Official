// import React from 'react';
// import photo_1 from '/Users/laharikemburu/Desktop/codegnan/src/placements/Photos/1.webp';
// import photo_2 from './Photos/2.webp';
// import photo_3 from './Photos/3.webp';
// import photo_4 from './Photos/4.webp';
// import photo_5 from './Photos/5.webp';
// import photo_6 from './Photos/6.webp';
// import photo_7 from './Photos/7.webp';
// import photo_8 from './Photos/8.webp';
// import photo_9 from './Photos/9.webp';
// import photo_10 from './Photos/10.webp';
// import photo_11 from './Photos/11.webp';
// import photo_12 from './Photos/12.webp';
// import photo_13 from './Photos/13.webp';
// import photo_14 from './Photos/14.webp';
// import photo_15 from './Photos/15.webp';
// import photo_16 from './Photos/16.webp';
// import photo_17 from './Photos/17.webp';
// import photo_18 from './Photos/18.webp';
// import photo_19 from './Photos/19.webp';
// import photo_20 from './Photos/20.webp';
// import photo_21 from './Photos/21.webp';
// import photo_22 from './Photos/22.webp';
// import photo_23 from './Photos/23.webp';
// import photo_24 from './Photos/24.webp';
// import photo_25 from './Photos/25.webp';
// import photo_26 from './Photos/26.webp';
// import photo_27 from './Photos/27.webp';
// import photo_28 from './Photos/28.webp';
// import photo_29 from './Photos/29.webp';
// import photo_30 from './Photos/30.webp';
// import photo_31 from './Photos/31.webp';
// import photo_32 from './Photos/32.webp';
// import photo_33 from './Photos/33.webp';
// import photo_34 from './Photos/34.webp';
// import photo_35 from './Photos/35.webp';
// import photo_36 from './Photos/36.webp';
// import photo_37 from './Photos/37.webp';
// import photo_38 from './Photos/38.webp';
// import photo_39 from './Photos/39.webp';
// import photo_40 from './Photos/40.webp';
// import photo_41 from './Photos/41.webp';
// import photo_42 from './Photos/42.webp';
// import photo_43 from './Photos/43.webp';
// import photo_44 from './Photos/44.webp';
// import photo_45 from './Photos/45.webp';
// import photo_46 from './Photos/46.webp';
// import photo_47 from './Photos/47.webp';
// import photo_48 from './Photos/48.webp';
// import photo_49 from './Photos/49.webp';
// import photo_50 from './Photos/50.webp';
// import photo_51 from './Photos/51.webp';
// import photo_52 from './Photos/52.webp';
// import photo_53 from './Photos/53.webp';
// import photo_54 from './Photos/54.webp';
// import photo_55 from './Photos/55.webp';
// import photo_56 from './Photos/56.webp';
// import photo_57 from './Photos/57.webp';
// import photo_58 from './Photos/58.webp';
// import photo_59 from './Photos/59.webp';
// import photo_60 from './Photos/60.webp';
// import photo_61 from './Photos/61.webp';
// import photo_62 from './Photos/62.webp';
// import photo_63 from './Photos/63.webp';

// const PhotoComponent = ({ photo1, photo2, photo3 }) => {
//   return (
//     <div className='Placement_photos'>
//       <img className='Photo' src={photo1} alt='Photo 1' />
//       <img className='Photo' src={photo2} alt='Photo 2' />
//       <img className='Photo' src={photo3} alt='Photo 3' />
//     </div>
//   );
// };

// class MainComponent extends React.Component {
//   render() {
//     return (
//       <div>
//         <PhotoComponent
//           photo1={photo_1}
//           photo2={photo_2}
//           photo3={photo_3}
//         />
//       </div>
//     );
//   }
// }

// export default MainComponent;