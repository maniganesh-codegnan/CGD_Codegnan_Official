// import Java from '../Internship/java';
import Java from '../Internship/java';

 function JavaCurriculum() {
  alert('hello')
  return (
    <div>
        <Java />
    </div>
  );
}

export default JavaCurriculum;
